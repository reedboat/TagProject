<?php
require_once 'header/web.inc.php';
require_once 'inc/tags/interface.inc.php';
require_once 'inc/tags/tags.inc.php';


$profile_begin = microtime(true);

$prj = new Tags_Project('tcms.interface.tags');
$method ='get';
project_init_params($prj, $method);
$query = 'io_' . $method;

$site      = $query('site');
$news_id   = $query('news_id');

$errors = array(
    10 => 'Invalid Arguments',
    50 => 'get article failed',
);

try{
    if (empty($site) || empty($news_id)){
        _log("params error in getArticle site:$site, news_id:$news_id", "ERROR");
        throw new CmsInterfaceException(10);
    }

    $controller = $prj->rs->data->ext['tags'];
    $result = $controller->getArticle($site, $news_id);
    if ($result === false){
        throw new CmsInterfaceException(50);
    }
    $cost = microtime(true) - $profile_begin;
    $prj->fw->interface->out(0, 'success', $cost, $result);
}
catch(CmsInterfaceException $e){
    project_output_error($prj, $e, $errors);
}
catch(Exception $e){
    $this->fw->interface->out($e->getCode(), $e->getMessage(), '', '');
}
function _log($msg, $level='ERROR'){ global $prj; $prj->CLog->w($level, $msg);}
?>
