<?php
require_once 'header/web.inc.php';
require_once 'inc/tags/interface.inc.php';
require_once 'inc/tags/tags.inc.php';

/**
 * 本接口用来设置文章的标签
 * 需要传入文章的
 * 频道英文名称
 * 文章15位ID
 * 文章类型数字
 * 发布时间数字
 * 操作的用户
 * 文章的标签, 用分号;分割的字符串列表, 不超过10个
 */

$prj = new Tags_Project('tcms.interface.tags');
$method = "post";
$query  = 'io_' . $method;
project_init_params($prj, $method);

$site = $query('site');
$id   = $query('id');
$type = $query("type");
$time = $query('time');
$user = $query('user');
$source = $query('source');

$tags_str = trim($query('tags'));
define('TAGS_LIMIT', 10);

$errors = array(
    10 => '参数错误: site或Id未提供',
    11 => '参数错误：未指定标签',
    12 => '参数错误: 发布时间或文章类型不正确',
    13 => '参数错误：标签过多',
    14 => '参数错误：未指定用户',
    15 => '参数错误：未指定来源',
    90 => '处理错误: 设定标签失败'
);

#$logger = new WF_Logger(new Boss(TAG_BOSS_ID));

try {
    list($site, $id, $type, $time, $tags) = _check_parameters($site, $id, $type, $time, $tags_str, $user, $source);
    
    //main process {{{
    $controller = $prj->rs->data->ext['tags'];

    $logger = WF_Registry::get('logger');
    _log($logger->format(array('SetTags', 'site'=>$site, 'id'=>$id, 'user'=>$user, 'source'=>$source)), 'INFO');
    $result = $controller->setNewsTags($site, $id, $tags, $type, $time);
    //}}}


    if (!$result){
        throw new CmsInterfaceException(90);
        _log("标签设定失败, site:$site; id:$id; tags:$tags_str", 'ERROR');
    }
    $prj->fw->interface->out(0, 'success', '', true);
}
catch(CmsInterfaceException $e){
    project_output_error($prj, $e, $errors);
}
catch(Exception $e){
    $this->fw->interface->out($e->getCode(), $e->getMessage(), '', '');
}


function _check_parameters($site, $id, $type, $time, $tags_str, $user, $source){
    global $prj;
    if (empty($user)){
        throw new CmsInterfaceException(14);
        _log("参数错误 site:$site;id:$id;", 'DEBUG');
    }
    if (empty($source)){
        throw new CmsInterfaceException(15);
        _log("参数错误 site:$site;id:$id;", 'DEBUG');
    }
    if (empty($site) || empty($id)){
        throw new CmsInterfaceException(10);
        _log("参数错误 site:$site;id:$id;", 'DEBUG');
    }
    if (empty($tags_str)){
        throw new CmsInterfaceException(11);
        _log("未指定标签, site:$site;id:$id", 'DEBUG');
    }
    if (empty($time) || $type == null) {
        throw new CmsInterfaceException(12);
        _log("参数错误 $site;id:$id;time:$time;type:$type;tags_str:$tags_str", 'DEBUG');
    }

    //过滤输入, 转义输出
    $tags_str = strip_tags($tags_str);
    $tags_str = project_convert_input($prj, $tags_str);
    $tags = ArticleTags::model()->str2arr($tags_str);
    if (sizeof($tags) == 0){
        throw new CmsInterfaceException(11);
    }
    if (sizeof($tags) > TAGS_LIMIT) {
        throw new CmsInterfaceException(13);
    }
    return array($site, $id, $type, $time, $tags);
}

function _log($msg, $level='ERROR'){ global $prj; $prj->CLog->w($level, $msg);}
