<?php
/**
 * 
 **/
class TagArticles extends WF_Table
{
    public $primaryKey = 'id';
    protected $_columns   = array('id', 'tag_id', 'site_id', "type", 'news_id', 'time');
    protected $source = 'web'; // source 表示标签的来源，是来自无线还是网站

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
        $prefix = WF_Registry::get('prefix', 'tbl_');
		return $prefix . 'tag_articles';
	}

    /**
     * search 根据Tag查找文章
     * tag_id 查找所有文章，按时间排序
     * tag_id,site 查找某个频道下的所有文章, 按时间排序
     * tag_id,type 查找某种类型的文章,按时间排序
     * tag_id,type,site 查找某个频道下某种类型的文章, 按时间排序
     * 
     * @param mixed $tag_id 
     * @param int $site_id 
     * @param int $len 
     * @param int $offset 
     * @access public
     * @return void
     * @static
     */
    public function search($tag_id, $site_id=0, $type=null, $source='web', $len=20, $offset=0){
        $store = WF_Registry::get('redis');
        $key   = TagsKey::keyTagArticles($tag_id, $site_id, $type, $source);
        $end   = $offset + $len - 1;
        $items = $store->zReverseRange($key, $offset, $end);
        $pks   = array();
        foreach($items as $item){
            $pk = json_decode($item, true);
            $pks[] = array('site_id'=>$pk[0], 'news_id'=>$pk[1]);
        }
        return $pks;


        //!todo 暂时不再从mysql中取数据
        $criteria = array();
        $criteria['order']     = 'time desc';
        $criteria['condition'] = 'tag_id = :tag_id';
        $criteria['params']    = array(':tag_id' => $tag_id);
        if ($site_id > 0){
            $criteria['condition'] .= ' AND site_id = :site_id';
            $criteria['params'][':site_id'] = $site_id;
        }
        if ($type !== null){
            $criteria['condition'] .= ' AND type= :type';
            $criteria['params'][':type'] = $type;
        }

        $criteria['limit']     = "$offset, $len";
        return $this->findAll($criteria, array('model'=>false));
    }

    public function count($tag_id, $site_id=0 ,$type=null, $source_id = 1){
        $store = WF_Registry::get('redis');
        $key   = TagsKey::keyTagArticles($tag_id, $site_id, $type);
        $total = $store->zCard($key);
        return $total;
    }

    public function index($tag_id, $data){
        $this->setAttributes(array(
            'tag_id'  => $tag_id,
            'site_id' => $data['site_id'],
            'news_id' => $data['news_id'],
            'type'    => $data['type'],
            'time'    => isset($data['time']) ? $data['time'] : time(),
        ));
        $this->_new = true;
        $this->id   = 0;
        return $this->save();
    }

    public function removeIndex($tag_id, $data){
       $this->setAttributes(array(
            'tag_id'  => $tag_id,
            'site_id' => $data['site_id'],
            'news_id' => $data['news_id'],
            'type'    => $data['type'],
        ));
       $conditions = array('tag_id'=>$this->tag_id, 'site_id'=>$this->site_id, "news_id"=>$this->news_id);
       return $this->delete($conditions);
    }

    public function onAddArticleTag(WF_Event $event){
        $tag = Tag::fetch($event->tag);
        if ($tag){
            $tag->increment(1);
        }
        else {
            $tag = new Tag();
            $tag->setName($event->tag);
            $result = $tag->save();
        }

        $data = $event->data();
        unset($data['tag']);

        $obj = new TagArticles();
        $obj->index($tag->id, $data);
        return true;
    }

    public function onRemoveArticleTag(WF_Event $event){
        $tag = Tag::fetch($event->tag);
        if($tag) {
            $tag->increment(-1);
        }
        else {
            return false;
        }
        $data = $event->data();
        unset($data['tag']);

        $obj = new TagArticles();
        $obj->removeIndex($tag->id, $data);
        return true;
    }

    /**
     * addTagIndexCache 更新redis数据
     * 
     * @param mixed $key 
     * @access protected
     * @return void
     */
    protected function beforeSave(){
        $store = WF_Registry::get('redis');
        $data = json_encode(array($this->site_id, $this->news_id));

        $keys = TagsKey::keysAllTagArticles($this->tag_id, $this->site_id, $this->type);
        foreach($keys as $key){
            $store->zAdd($key, $this->time, $data);
        }
        //todo 暂时不再写mysql了。 
        return false;
    }

    protected function beforeDelete(){
        $store = WF_Registry::get('redis');
        $data = json_encode(array($this->site_id,$this->news_id));

        $keys = TagsKey::keysAllTagArticles($this->tag_id, $this->site_id, $this->type, $this->source);

        foreach($keys as $key){
            $store->zDelete($key, $data);
        }
        //todo 暂时也不再从mysql删除了。 
        return false;
    }
}
