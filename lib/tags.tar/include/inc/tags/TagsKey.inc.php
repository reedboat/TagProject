<?php
/**
 * TagsKey 生成缓存的Key， 注意前缀必须保持不同。
 */
class TagsKey {
    public static function keyArticleTags($site_id, $news_id){
        return 'TAT_' . $site_id . '_' . $news_id;
    }

    public static function keyTagNameId($name){
        return 'TNI_' . $name;
    }

    public static function keyTag($id){
        return "TIT_$id";
    }

    public static function keyArticleMini($site_id, $news_id){
        return "TAM_${site_id}_${news_id}";
    }

    public static function keySiteNameId($site_name){
        return 'TSN_' . $site_name;
    }

    public static function keySiteIdName($site_id){
        return 'TSI_' . $site_id;
    }

    public static function keyTagArticles($tag_id, $site_id, $type){
        $type    = $type === null ? 'A' : $type;
        return "TTA_${tag_id}_${site_id}_${type}";
    }

    public static function keysAllTagArticles($tag_id, $site_id, $type){
        $keys = array(
            self::keyTagArticles($tag_id, 0, null),
        );
        if ($site_id > 0){
            $keys[] = self::keyTagArticles($tag_id, $site_id, null);
            if ($type !== null){
                $keys[] = self::keyTagArticles($tag_id, $site_id, $type);
            }
        }
        if ($type !== null){
            $keys[] = self::keyTagArticles($tag_id, 0, $type);
        }
        return $keys;
    }
}
?>
