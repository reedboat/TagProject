<?php
/**
 * TagsKey 生成缓存的Key， 注意前缀必须保持不同。
 */
class TagsKey {
    public static function keyArticleTags($site_id, $news_id){
        return 'TAT_' . $site_id . '_' . $news_id;
    }

    public static function keyTagNameId($name){
        return 'TNI_' . $name;
    }

    public static function keyTag($id){
        return "TIT_$id";
    }

    public static function keyArticleMini($site_id, $news_id){
        return "TAM_${site_id}_${news_id}";
    }

    public static function keySiteNameId($site_name){
        return 'TSN_' . $site_name;
    }

    public static function keySiteIdName($site_id){
        return 'TSI_' . $site_id;
    }

    public static function keyTagArticles($tag_id, $site_id, $type, $source='web'){
        $type    = $type === null ? 'A' : $type;
        if ($source == 'web'){
            $source_flag = 'w';
        }
        elseif ($source == 'mobile'){
            $source_flag = 'w';
        }
        return "TTA_${tag_id}_${site_id}_${type}_${source_flag}";
    }

    private static function _keysAllTagArticles($tag_id, $site_id, $type, $source){
        $keys = array();
        $keys[] = self::keyTagArticles($tag_id, 0, null, $source);
        if ($site_id > 0){
            $keys[] = self::keyTagArticles($tag_id, $site_id, null, $source);
            if ($type !== null){
                $keys[] = self::keyTagArticles($tag_id, $site_id, $type, $source);
            }
        }
        if ($type !== null){
            $keys[] = self::keyTagArticles($tag_id, 0, $type, $source);
        }
        return $keys;
        return $keys;
    }

    public static function keysAllTagArticles($tag_id, $site_id, $type, $source = 'web'){
        if ($source == 'web'){
            $keys = self::_keysAllTagArticles($tag_id, $site_id, $type, $source);
        }
        else if ($source == 'mobile'){
            $keys = self::_keysAllTagArticles($tag_id, $site_id, $type, $source);
            $keys += self::_keysAllTagArticles($tag_id, $site_id, $type, 'web');
        }
        return $keys;
    }

    public static function keyKeywordSuggest($keyword){
        $key = 'TKS_' . md5($keyword);
        return $key;
    }

    public static function keyInputSuggest($input){
        $key = 'TIS_';
        if (preg_match('/^\w$/', $input)) {
            $key .= $input;
        } else {
            $key .= md5($input);
        }
        return $key;
    }
}
?>
