<?php
class ArticleTags extends WF_Table
{
    public $primaryKey = array('site_id', 'news_id');
    protected $delimiter  = ';';
    protected $time       = 0;
    protected $type       = 0;
    protected $_columns   = array(
        'site_id', 'news_id', 'tags', 'create_time', 'update_time'
    );

    /**
     * model 使用model类，避免用静态方法
     * 
     * @param mixed $className 
     * @static
     * @access public
     * @return void
     */
    public static function model($className = __CLASS__){
        return parent::model($className);
    }

    public function tableName(){
        $prefix = WF_Config::get('prefix', 'tbl_');
        return $prefix . "article_tags";
    }

    public function saveTags($tags){
        $this->tags = $this->arr2str($tags);
        $res = $this->save();
        if (!$res) {
            return false;
        }

        foreach($tags as $tag){
            $data = array(
                'site_id' => $this->site_id,
                'news_id' => $this->news_id,
                'type'    => $this->type,
                'time'    => $this->time,
                'tag'     => $tag
            );
            WF_Event::fire('addArticleTag', $data);
            unset($data);
        }
        return true;
    }

    public function updateTags($new_tags){
        $this->setNewRecord(false);
        $old_tags = $this->str2arr($this->tags);
        $this->tags = $this->arr2str($new_tags);
        $res = $this->save();

        if (!$res) {
            return false;
        }

        $common_tags = array_intersect($old_tags, $new_tags);

        foreach(array_diff($old_tags, $common_tags) as $tag){
            $data = array(
                'site_id' => $this->site_id,
                'news_id' => $this->news_id,
                'tag'     => $tag
            );
            WF_Event::fire('removeArticleTag', $data);
        }
        foreach(array_diff($new_tags, $common_tags) as $tag) {
            $data = array(
                'site_id' => $this->site_id,
                'news_id' => $this->news_id,
                'type'    => $this->type,
                'time'    => $this->time,
                'tag'     => $tag
            );
            WF_Event::fire('addArticleTag',$data);
        }

        return true;
    }

    /**
     * 将Tag表中的
     * 
     * @return 
     * @access 
     **/
    public function changeTag($from, $to){
        $from = trim($from);
        $to   = trim($to);
        $tags_arr = $this->str2arr($this->tags);
        if (!in_array($to, $tags_arr) && in_array($from, $tags_arr)) {
            $this->tags = str_replace($from, $to, $this->tags);
            $this->save();
            $data = array(
                'site_id' => $this->site_id,
                'news_id' => $this->news_id,
                'type'    => $this->type,
                'time'    => $this->time,
                'tag'     => $from,
            );
            WF_Event::fire('removeArticleTag', $data);
            $data['tag'] = $to;
            WF_Event::fire('addArticleTag', $data);
        }
    }

    public function str2arr($str) {
        return explode($this->delimiter, $str);
    }

    public function arr2str($arr) {
        return implode($this->delimiter, $arr);
    }

    public function beforeSave() {
        if (parent::beforeSave()){
            if ($this->create_time <= 0) {
                $this->create_time = $this->update_time = time();                
                return true;
            }
            $this->update_time = time();
            return true;
        }
        return false;
    }

    /**
     * afterSave 刷新redis缓存
     * 
     * @param mixed $type 
     * @access public
     * @return void
     */
    public function afterSave($type){
        if (parent::afterSave()){
            $store = WF_Registry::get('redis');
            $key = TagsKey::keyArticleTags($this->site_id, $this->news_id);
            $store->set($key, $this->tags);
            return true;
        }
        return false;
    }

    /**
     * getTags 从缓存中读取Tags
     * 
     * @param mixed $site_id 
     * @param mixed $news_id 
     * @access public
     * @return void
     */
    public function getTags($site_id=0, $news_id=0){
        if (func_num_args() == 0){
            return $this->str2arr($this->tags);
        }

        $store = WF_Registry::get('redis');
        $key = TagsKey::keyArticleTags($site_id, $news_id);
        $tags = $store->get($key);
        return $tags ? $this->str2arr($tags) : array();
    }

    /**
     * id gen tool for unit test 
     * 
     * @param mixed $id 
     * @return void
     */
    public static function genId($id){
        return date("Ymd") . sprintf("%07s", $id);
    }
}
