<?php
/**
 * TagReport 
 * 
 * @uses Report_Boss 向Tag汇报
 * @author kufazhang <zhqm03@gmail.com> 
 */
class TagReport extends Report_Boss {

    public function reportSet($site, $article_id, $tags, $user, $source='default', $result='T'){
        $data = array
        (
            'op'          => 'setArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'columns'     => '',                               
            'articleid'   => $article_id,
            'startTime'   => time(),
            'endTime'     => 0,
            'timeLapse'   => $tags,
            'extendData1' => $source,
            'extendData2' => $result, //T表示成功，F表示失败
            'extendData3' => 0,
            'extendData4' => 0,
            'extendData5' => 0,
        );
        $this->report($data);
    }

    public function reportGet($site, $article_id, $user=''){
        $data = array(
            'op'          => 'getArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'columns'     => '',                               
            'articleid'   => $article_id,
            'startTime'   => time(),
            'endTime'     => 0,
            'timeLapse'   => $tags,
            'extendData1' => $source,
            'extendData2' => '',
            'extendData3' => 0,
            'extendData4' => 0,
            'extendData5' => 0,
        );
        $this->report($data);
    }

    public function reportMget($site, $ids, $user=''){
        $data = array(
            'op'          => 'mgetArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'columns'     => '',                               
            'articleid'   => $ids,
            'startTime'   => time(),
            'endTime'     => 0,
            'timeLapse'   => $tags,
            'extendData1' => $source,
            'extendData2' => '',
            'extendData3' => 0,
            'extendData4' => 0,
            'extendData5' => 0,
        );
        $this->report($data);
    }

    public function reportList($tag, $site, $type, $page=1, $len=20){
        $data = array(
            'op'          => 'listTagArticles',
            'editor'      => '',
            'site'        => $site,
            'columns'     => '',                               
            'articleid'   => $ids,
            'startTime'   => time(),
            'endTime'     => 0,
            'timeLapse'   => $tags,
            'extendData1' => '',
            'extendData2' => '', 
            'extendData3' => $type, //文章类型
            'extendData4' => $page,
            'extendData5' => $len,
        );
        $this->report($data);
    }
}
?>
