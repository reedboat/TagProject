<?php
class Tags_Project extends TProject {
    private $pidFileName = '';
    private $lockFileName = '';
    public function __construct($idListString, $param = array()){
        $this->dbClassName = 'WF_Db';
        parent::__construct($idListString, $param);
    }

    public function init(){
        parent::init();
        $logger = new WF_Logger($this->CLog);
        WF_Registry::set('logger', $logger);
        WF_Registry::set('db', $this->CData->CDb->w);
    }

    public function allocResource(){
        global $g_resource;
        parent::allocResource();
        if (!empty($g_resource[$this->idString])){
            if (isset($g_resource[$this->idString]['redis'])){
                $redis_config = $g_resource[$this->idString]['redis'];
                $redis_config = $redis_config['default']['serverList'][0];

                $redis = new Redis();
                $redis_config = array('host'=>'127.0.0.1', 'port'=>6379);
                $redis->connect($redis_config['host'], $redis_config['port']);
                WF_Registry::set('redis', $redis);
            }
        }
    }
}
