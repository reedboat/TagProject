<?php
class ArticleMini extends WF_Table {
    public $primaryKey  = array('Fsite_id', 'Farticle_id');
    protected $_columns = array('Fsite_id', 'Farticle_id', 'Ftitle', 'Fpub_time', 'Ftype', 'Fmeta');

    public function tableName(){
        $prefix = WF_Registry::get('prefix', 'tbl_');
        return $prefix . "article_mini";
    }

    public static function model($className = __class__){
        return parent::model($className);
    }


    public function addArticle($site_id, $article_id, $title, $type=0, $pub_time=0, $meta = array()){
        if ($pub_time == 0) {
            $pub_time = date("c");
        }
        $className = __CLASS__;
        $article = new $className;
        $article ->setAttributes(array(
            'Fsite_id'    => $site_id,
            'Farticle_id' => $article_id,
            'Ftitle'      => $title,
            'Fpub_time'   => $pub_time,
            'Ftype'       => $type,
            'Fmeta'       => json_encode($meta),
        ));
        return $article->save();
    }

    /**
     * findArticles 根据ID 批量查找文章
     * 
     * @todo 是否做成批量查询?
     * @param mixed $pk_list 
     * @access public
     * @return void
     */
    public function findArticles($pk_list){
        //@todo check $pk_list
        $ret = array();
        if (is_string($pk_list)){
            $site_id = $pk_list;
            $args = func_get_args();
            if (count($args)!=2 || !is_array($args[1])){
                throw new InvalidArgumentException("ArticleMini::findArticles arguments erro");
            }
            $id_list = $args[1];
            
            $pk_list = array(); 
            foreach($id_list as $news_id){
                $pk_list[] = array($site_id, $news_id);
            }
        }

        foreach($pk_list as $pk){
            //$article = $this->findByPk($pk, array('model'=>false));
            $article = $this->getArticle($pk[0], $pk[1]);
            array_push($ret, $article);
        }  

        return $ret;
    }

    public function getArticle($site_id, $news_id){
        $store = WF_Registry::get('redis');
        $key = TagsKey::keyArticleMini($site_id, $news_id);
        $data = $store->get($key);
        $article = $data ? json_decode($data, true) : null;  
        return $article;
    }

    protected function afterSave($type){
        $key = TagsKey::keyArticleMini($this->Fsite_id, $this->Farticle_id);
        $store = WF_Registry::get('redis');
        $data = $this->getAttributes();
        $store->set($key, json_encode($data));
    }
}
?>
