<?php
require_once 'inc/tags/lib/Loader.class.php';
WF_Loader::registerAutoload();

require_once 'inc/tags/Tag.inc.php';
require_once 'inc/tags/TagArticles.inc.php';
require_once 'inc/tags/ArticleTags.inc.php';
require_once 'inc/tags/ArticleMini.inc.php';
require_once 'inc/tags/TagSite.inc.php';
#require_once 'inc/tags/TagReport.inc.php';
require_once 'inc/tags/TagsKey.inc.php';
require_once 'inc/tags/TagsProject.inc.php';
