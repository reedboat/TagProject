<?php
class Tag extends WF_Table
{
    public $primaryKey = 'id';
    protected $_columns  = array('id', 'name', 'frequency', 'create_time', 'category', 'metadata');

    public function tableName()
    {
        $prefix = WF_Registry::get('prefix', 'tbl_');
        return $prefix . 'tag';
    }

    public static function model($className = __class__)
    {
        return parent::model($className);
    }

    public function suggestByPrefix($prefix, $limit=10)
    {
        $rows=$this->findAll(array(
            'condition'=>'name LIKE :keyword',
            'order'=>'frequency DESC, Name',
            'limit'=>$limit,
            'params'=>array(
                ':keyword'=>strtr($prefix,array('%'=>'\%', '_'=>'\_', '\\'=>'\\\\')).'%',
            ),
        ), array('model'=>false));
        $result=array();
        foreach($rows as $row)
        {
            $result[$row['name']] = $row['frequency'];
        }
        return $result;
    }

    public function suggestByKeyword($keyword, $limit=10)
    {
        $rows=$this->findAll(array(
            'condition'=>'name LIKE :keyword',
            'order'=>'frequency DESC, Name',
            'limit'=>$limit,
            'params'=>array(
                ':keyword'=>'%'.strtr($keyword,array('%'=>'\%', '_'=>'\_', '\\'=>'\\\\')).'%',
            ),
        ), array('model'=>false));
        $result=array();
        foreach($rows as $row)
        {
            $result[$row['name']] = $row['frequency'];
        }
        return $result;
    }

    public function getId($name){
        $store = WF_Registry::get('redis');
        $key = TagsKey::keyTagNameId($name);
        $id = $store->get($key);
        return $id;
    }

    public static function fetch($identity)
    {
        $store = WF_Registry::get('redis');
        if (is_string($identity))
        {
            $key = TagsKey::keyTagNameId($identity);
            $id = $store->get($key);
        }
        else {
            $id = $identity;
        }
        return self::model()->findByPk($id);
    }

    public function rename($new_name)
    {
        if ($this->id >0)
        {
            $this->name = $new_name; 
            $this->name_changed = true;
            $result = $this->save();
            return $result;
        }
        else {
            throw new LogicException("tag to rename must exist");
        }
    }

    public function increment($weight=1)
    {
        $this->frequency += $weight;
        $result = $this->save();
        return $result;
    }

    public function saveIfNotExist()
    {
        if (!self::fetch($this->name))
        {
            return $this->save();
        }
        return false;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    protected function beforeSave()
    {
        if (parent::beforeSave())
        {
            if ($this->isNewRecord())
            {
                if (!isset($this->create_time))
                {
                    $this->setAttribute('create_time', time());
                }
                if (!isset($this->frequency))
                {
                    $this->setAttribute('frequency', 1);
                }
            }
            return true;
        }
        return false;
    }

    protected function afterSave($type)
    {
        $key = TagsKey::keyTag($this->id);
        $store = WF_Registry::get('redis');
        $store->set($key, json_encode($this->getAttributes()));
        if ($type == 'insert' || $this->name_changed)
        {
            $key = TagsKey::keyTagNameId($this->name);
            $store->set($key, $this->id);
        }
        return true;
    }
}
