<?php
class TagSite {
    private static $key_name_id = 'sites_name_id_map';
    private static $key_id_name = 'sites_id_name_map';
    private static $site_name_id_map = null;
    private static $site_id_name_map = null;

    public static function getSiteId($site_name){
        if (!self::$site_name_id_map){
            $store = WF_Registry::get('redis');
            self::$site_name_id_map = $store->hGetAll(self::$key_name_id);
        }
        return self::$site_name_id_map[$site_name];
    }

    public static function getSite($site_id){
        if (!self::$site_id_name_map){
            $store = WF_Registry::get('redis');
            self::$site_id_name_map = $store->hGetAll(self::$key_id_name);
        }
        return self::$site_id_name_map[$site_id];
    }

    public function refresh($config){
        if (is_array($config)){
            $db = new WF_Db($config);
            $stmt = $db->query("select * from Fsearch_id, Fsite_id from site_config.t_site_info");
            $rows = $stmt->fetchAll();
            $sites = array();
            foreach($rows as $row){
                $sites[$row[0]] = $row[1];  
            }
        }
        if (is_string($config)){
            $lines = file($config);
            $sites = array();
            foreach($lines as $line){
                list($name, $id) = explode("\t", $line);
                $id = trim($id);
                $sites[$id] = $name;
            }
        }
        $store = WF_Registry::get('redis');
        $store->hMset(self::$key_id_name, $sites);
        $store->hMset(self::$key_name_id, array_flip($sites));
    }
}
?>
