<?php
class WF_Cache {
    private $store = null;

    function __construct($store) {
        if ($store && $store instanceof Redis){
            $this->store = $store;
        }
        else if (is_string($store) && WF_Registry::has($store)){
            $this->store = WF_Registry::get($store);
        }
        else {
            throw new Exception('must provide redis instance for cache');
        }
    }

    public function __call($func, $args){
        if (method_exists($this->store, $func)){
            return call_user_func_array(array($this->store, $func), $args);
        }
        throw new BadMethodCallException("call by wrong method name $func of " . __CLASS__);
    }

    public function set($key, $value, $lifetime=0){
        if ($lifetime > 0){
            return $this->store->setex($key, $lifetime, $value);
        }
        return $this->store->set($key, $value);
    }

    public function add($key, $value, $lifetime=0){
        if ($this->store->exists($key)) return false;
        return $this->set($key, $value, $lifetime);
    }
}
?>
