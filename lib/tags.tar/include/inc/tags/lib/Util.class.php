<?php
class WF_Util{
    public static function getFuncName($callback){
        if (is_array($callback)){
            if(is_string($callback[0])){
                $name = $callback[0];
            }
            else if (is_object($callback[0])){
                $name = get_class($callback[0]);
            }
            $func = $name . "::" . $callback[1];
        }
        else {
            $func = $callback;
        }
        return $func;
    }
}
?>
