<?php
class WF_Loader{
    public static function registerAutoload(){
        return spl_autoload_register(array(__CLASS__, 'includeClass'));
    }
    
    public static function includeClass($name){
        if (substr($name, 0, 3) == 'WF_'){
            $file = substr($name, 3) . ".class.php";
            $path = __DIR__  . '/' . $file;
            if (file_exists($path)){
                require $path;
            }
        }
        return false;
    }
}
?>
