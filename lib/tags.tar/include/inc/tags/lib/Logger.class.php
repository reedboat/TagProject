<?php
class WF_Logger{
    private $backend;
    private static $instance = null;

    public function __construct($clog=null){
        $this->backend = $clog;
    }

    public static function instance($clog = null){
        if (self::$instance == null){
            $className = __CLASS__;
            self::$instance = new $className($clog);
        }
        return self::$instance;
    }

    public function report(){
        if (!$this->boss == null) {
            $this->boss = new Report_Boss(array('loadId'=> 0));
        }
        $this->boss->report($data);
    }

    public function log($msg, $level){
        if ($this->backend instanceof Until_Log_Web){
            $this->backend->w('info', $msg);
        }
        elseif ($this->backend == null){
            error_log(date('r'). " Logger $level $msg");
        }
        else {
            $this->backend->log($msg, $level);
        }
    }

    public function debug($msg){
        $this->log($msg, 'DEBUG');
    }

    public function info($msg){
        $this->log($msg, 'INFO');
    }

    public function error($msg){
        $this->log($msg, 'ERROR');
    }

    public function warn($msg){
        $this->log($msg, 'WARN');
    }

    /**
     * format 将数组格式化成Tab分割的字符串序列
     * 
     * @param mixed $data 
     * @access public
     * @return void
     */
    public function format($data){
        if (is_string($data)) return $data;
        $arr = array();
        foreach($data as $key => $value){
            if (is_integer($key)){
                array_push($arr, $value);
            }
            else {
                array_push($arr, strtolower($key));
                if (is_null($value)){
                    $value = '-';
                }
                array_push($arr, $value);
            }
        }
        return implode("\t", $arr);
    }
}
?>
