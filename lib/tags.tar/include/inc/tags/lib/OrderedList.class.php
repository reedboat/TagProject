<?php
class WF_OrderedList {
    private $key  = 'default';
    private $size = 1000;
    private $min_score = -100;
    private $trim_chance = 1;
    private $timeout = 5;
    private $store = null;

    public function __construct($key=null, $store=null, $options = array())
    {
        $this->key  = $key;

        if (is_object($store) && $store instanceof Redis)
        {
            $this->store = $store;
        } else if (is_string($store) && WF_Registry::has($store))
        {
            $this->store = WF_Registry::get($store);
        }

        $this->size = isset($options['size']) ? intval($options['size']) : -1;
        if (isset($options['min_score']))
        {
            $this->min_score = $options['min_score'];
        }

        if (isset($options['trim_chance']))
        {
            $this->min_score = $options['trim_chance'];
        }
    }

    public function setKey($key)
    {
        $this->key = $key;
    }

    public function add($member, $score)
    {
        $this->store->zAdd($this->key, $score, $member);
        if ($this->shouldTrim())
        {
            $this->trim();
        }
    }

    public function shouldTrim()
    {
        if ($this->size > 0 || $this->trim_chance < 1)
        {
            return rand(0, 100000) / 100000.0 <= $this->trim_chance;
        }
        return false;
    }

    public function trim()
    {
        $edge_member = $this->store->zReverseRange($this->key, $this->size, $this->size, true);
        if ($edge_member && !empty($edge_member))
        {
            $edge_score = array_shift($edge_member);
            $this->store->zDeleteRange($this->key, $this->min_score, $edge_score);
        }
        return true;
    }

    public function range($count=20, $offset=0, $with_score = 1)
    {
        $end = $offset + $count;
        $start = $offset;
        $result = $this->store->zReverseRange($this->key, $start, $end, $with_score);
        return $result;
    }
}

