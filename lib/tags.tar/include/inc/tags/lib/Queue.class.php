<?php 
/**
 * 基于Redis的消息队列
 */
class WF_Queue {
    protected /*Redis*/ $store;
    protected $queue_name;
    protected $timeout = 0;

    public function __construct($queue_name, $store='redis') {
        $this->queue_name = $queue_name;
        if ($store && $store instanceof Redis){
            $this->store = $store;
        }
        else if (is_string($store) && WF_Registry::has($store)){
            $this->store = WF_Registry::get($store);
        }
    }

    public function setStore($redis) {
        if ($redis instanceof Redis){
            $this->store = $redis;
        }
        else {
            throw new DomainException("havn't provide redis resource");
        }
    }

    public function setTimeout($timeout){
        $this->timeout = (int)$timeout;
    }

    public function enqueue($item){
        if (!$this->store){
            throw new DomainException("havn't provide redis resource");
        }
 
        return $this->store->rPush($this->queue_name, $item);
    }

    public function dequeue($direction='left'){
        if (!$this->store){
            throw new DomainException("havn't provide redis resource");
        }

        $item = false;
        $pop_method = $direction == 'left' ? 'lPop' : 'rPop';
        if ($this->timeout > 0) {
            $pop_method = "b$pop_method";
            $result = $this->store->$pop_method($this->queue_name, $this->timeout);
            if (is_array($result)) {
                $item = $result[1];
            }
        }
        else {
            $item = $this->store->$pop_method($this->queue_name);
        }
        return $item;
    }

    public function length(){
        return $this->store->lSize($this->queue_name);
    }
}
