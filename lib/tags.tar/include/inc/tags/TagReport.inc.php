<?php
/**
 * TagReport 
 * 
 * @uses Report_Boss 向Tag汇报
 * @author kufazhang <zhqm03@gmail.com> 
 */
class TagReport extends Report_Boss {
    public $loadId = 1524;
    public $biz = 'tags';

    public function reportSet($site, $article_id, $tags, $user, $source='default', $result='T'){
        $data = array
        (
            'op'          => 'setArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'articleid'   => $article_id,
            'tags'        => $tags,
            'result'      => $result,
            'extendData1' => $source,
        );
        $this->report($data);
    }

    public function reportGet($site, $article_id, $user=''){
        $data = array(
            'op'          => 'getArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'articleid'   => $article_id,
            'tags'        => '-',
            'result'      => 'T',
            'extendData1' => $source,
        );
        $this->report($data);
    }

    public function reportMget($site, $ids, $user=''){
        $data = array(
            'op'          => 'mgetArticleTags',
            'editor'      => $user,
            'site'        => $site,
            'articleid'   => $ids,
            'tags'        => '-',
            'extendData1' => $source,
        );
        $this->report($data);
    }

    public function reportList($tag, $site, $type, $page=1, $len=20){
        $data = array(
            'op'          => 'listTagArticles',
            'editor'      => '',
            'site'        => $site,
            'columns'     => '',                               
            'articleid'   => $ids,
            'timeLapse'   => $tags,
            'extendData1' => $source,
            'extendData3' => $type, //文章类型
            'extendData4' => $page,
            'extendData5' => $len,
        );
        $this->report($data);
    }
}
?>
