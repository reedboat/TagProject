<?php
/**
 * 
 **/
class AppData_Tags_Tags extends Base_TClass
{
    public function genKey($name)
    {
        $args = func_get_args();
        $name = array_shift($args);

        switch($name)
        {
        case 'NewsTags':
            $site    = $args[0];
            $news_id = $args[1];
            $key     = 'NewsTags_'  . $site . '_' . $news_id;
            break;
        case 'TagArticles':
            $tag     = $args[0] == 'all' ? 0 : $args[0];
            $site_id = $args[1];
            $type    = $args[2] === null ? 'A' : $args[2];
            $source  = $args[3];
            $key = "TL${tag_id}_${site_id}_${type}_${source}";
            break;
        case 'suggestByKeyword':
            $keyword = $args[0];
            $key="${name}_${keyword}";
            break;
        case 'suggestByInput':
            $input = $args[0];
            $key="${name}_${input}";
            break;

        default:
            $key = '__INVALID_KEY';
        }
        return $key;
    }

    /**
     * 根据文章ID，获取文章的Tags
     * @param string $site
     * @param string $news_id
     * @return array $tags
     **/
    public function getNewsTags($site, $news_id)
    {
        $site_id = TagSite::getSiteId($site);
        $tags = ArticleTags::model()->getTags($site_id, $news_id);
        return $tags;
    }


    /**
     * 根据文章ID，获取文章的Tags
     * @param string $site
     * @param string $news_id
     * @param array  $tags
     * @return boolean 设置成功与否 
     **/
    public function setNewsTags($site, $news_id, $tags, $type=null, $time=0)
    {
        $site_id = TagSite::getSiteId($site);
        $model = ArticleTags::model()->findByPk(array($site_id, $news_id));

        if ($model == null)
        {
            $model = new ArticleTags();
            $model->site_id = $site_id;
            $model->news_id = $news_id;
            if ($type === null){
                return false;
            }
            if ($time == 0){
                $time = time();
            }
            $model->type    = $type;
            $model->time    = $time;
            
            $result = $model->saveTags($tags);
        }
        else {
            $result = $model->updateTags($tags);
        }

        return $result;
    }

    /**
     * 获取建议的Tags，按照关键词和tags的加权权重排序
     * 
     * @return array $tags
     * @access 
     **/
    public function suggestByKeywords($keywords, $limit=10)
    {
        $result = array();
        $redis_key = WF_Config::get('suggest_redis', 'redis');
        #$util = new WF_CacheProxy(Tag::model(), new WF_Cache($redis_key));
        $cache = WF_Registry::get($redis_key);
        foreach($keywords as $keyword)
        {
            $key = TagsKey::keyKeywordSuggest($keyword);
            if ($value = $cache->get($key)){
                $tags = json_decode($value, true);
            }
            else {
                $tags = Tag::model()->suggestByKeyword($keyword);
                $cache->set($key, json_encode($tags), 180);
            }

            foreach($tags as $tag => $weight){
                if (isset($result[$tag])){
                    $result[$tag] += $weight;
                } else {
                    $result[$tag] = intval($weight);
                }
            }
        }
        arsort($result);
        return $result;
    }

    public function suggestByInput($input, $limit=50)
    {
        $redis_key = WF_Config::get('suggest_redis', 'redis');
        $cache = WF_Registry::get($redis_key);

        $key = TagsKey::keyInputSuggest($input);
        if ($value = $cache->get($key)){
            $tags = json_decode($value, true);
        }
        else {
            $tags = Tag::model()->suggestByPrefix($input);
            $cache->set($key, json_encode($tags), 180);
        }

        return $tags;
    }

    public function removeTag($tag)
    {
    }

    public function mergeTags($to, $from)
    {
    }

    public function findRelatedTags()
    {
    }

    public function listArticles($tag, $site_id=0, $type=null, $page=1, $len=20, $source='web')
    {


        $news_list = array();
        do{
            $tag_id = Tag::model()->getId($tag);
            if (!$tag_id) { break; }

            $key = TagsKey::keyTagArticles($tag_id, $site_id, $type, $source);
            $rows = TagArticles::model()->search($tag_id, $site_id, $type, $source, $len, $offset);
            if (empty($rows)){ break;}

            $pks = array();
            foreach($rows as $row)
            {
                $pks[] = array($row['site_id'], $row['news_id']);
            }
            $news_list = ArticleMini::model()->findArticles($pks);
        }while(0);

        return $news_list;
    }

    public function addArticle($site, $news_id, $title, $type=0, $time, $meta=array()){
        $site_id = TagSite::getSiteId($site);
        return ArticleMini::model()->addArticle($site_id, $news_id, $title, $type, $time, $meta);
    }

    public function getArticle($site, $news_id){
        $site_id = TagSite::getSiteId($site);
        return ArticleMini::model()->getArticle($site_id, $news_id);
    }
}
?>
